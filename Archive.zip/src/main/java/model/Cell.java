package main.java.model;

public class Cell {

}

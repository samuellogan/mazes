**[Work in progress]**

A simple java app that generates and solves mazes making use of popular algorythms

<img width="912" alt="Screenshot 2024-03-21 at 13 32 57" src="https://github.com/samuellogan/mazes/assets/42814104/0c3cea30-7347-4840-9ae5-ba6938deb64d">
